PODRÓŻE — PWA (CLEAN)

To jest czysta wersja apki: bez danych lotów/noclegów/miast w kodzie.

Aktualizacja na GitHub Pages:
1) Podmień w repo pliki: index.html, sw.js (manifest.webmanifest + icons/ zostają).
2) Odśwież stronę.

Telefon (żeby było 100% czysto):
- Odinstaluj apkę i zainstaluj ponownie
  ALBO w Chrome wyczyść dane witryny: goor5ky.github.io
